/* eslint-disable react/prop-types */
import { Link } from "react-router-dom"
import Button from "./Button"
import { getCookie } from "../utilities/getCSRF"
import { useContext } from "react"
import { UserContext } from "../context/userContext";

const Navbar = () => {
  const title = "Resource Management Portal"
  const login = getCookie("csrftoken");
  const {user, isUserInfoReady} = useContext(UserContext)

  console.log(user);

  return (
    <>
    <header className="bg-primary h-16  lg:h-[73px] -mx-4 md:-mx-20 px-4 md:px-20 flex justify-center items-center rounded-b-xl">
        <nav className="flex items-center justify-between w-full">
            
            <Link to={'/'}>
                <img
                    className="h-16" 
                    src="/logo/pict-logo.png" 
                    alt="logo of pict" />
            </Link>

            <div className="-mx-[10px] hidden md:block">
                <h1 className="text-2xl decoration-1 font-semibold text-white ">{title}</h1>
                <div className="-mx-6 border-t-white border mt-1"></div>
            </div>

            <div className="flex items-center gap-4 md:gap-6">
                {/* <p className="text-xl text-white">Add User</p>
                <p className="text-xl text-white">View Users</p> */}
                <Button to="/" className="hover:shadow-lg hover:text-primary hover:bg-white" name="Home"/>
                <Button to="/requests" className={"hover:shadow-lg hover:text-primary hover:bg-white " + (isUserInfoReady &&  user[" user Details"] && user[" user Details"].Role === 0 && " hidden ")} name="Requests" />
                <Button to="/profile" className={"hover:shadow-lg hover:text-primary hover:bg-white "} name="Profile" />
                <Button to="/login" name="Login"  className={"hover:shadow-lg hover:bg-white hover:text-primary hover:underline hover:outline-none " + (login && "hidden ")}/>
            </div>
            
        </nav>
    </header>
    <div className="-mx-[10px] md:hidden block">
    <h1 className="text-3xl  underline text-center mt-8 font-semibold ">{title}</h1>
  </div>
    </>
  )
}

export default Navbar