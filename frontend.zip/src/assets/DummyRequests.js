export const DummyRequests = [
    {
        id: 1,
        title: "Expert Talk on AI",
        by: "John Doe",
        date: "31 feb 2024",
        timing: "2pm-4pm",
        resource: "Comp Seminar Hall",
        organization: "Individual"
    },
    {
        id: 2,
        title: "Expert Talk on AI",
        by: "John Doe",
        date: "31 feb 2024",
        timing: "2pm-4pm",
        resource: "Comp Seminar Hall",
        organization: "Individual"
    },
    {
        id: 3,
        title: "Expert Talk on AI",
        by: "John Doe",
        date: "31 feb 2024",
        timing: "2pm-4pm",
        resource: "Comp Seminar Hall",
        organization: "Individual"
    },
    {
        id: 4,
        title: "Expert Talk on AI",
        by: "John Doe",
        date: "31 feb 2024",
        timing: "2pm-4pm",
        resource: "Comp Seminar Hall",
        organization: "Individual"
    },
    {
        id: 5,
        title: "Expert Talk on AI",
        by: "John Doe",
        date: "31 feb 2024",
        timing: "2pm-4pm",
        resource: "Comp Seminar Hall",
        organization: "Individual"
    }

];