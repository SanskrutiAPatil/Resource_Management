/* eslint-disable react/prop-types */
import axios from "axios";
import { createContext, useEffect, useState } from "react";
import { getCookie } from "../utilities/getCSRF";

export const UserContext = createContext({});

export const UserContextProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isUserInfoReady, setIsUserInfoReady]  = useState(false);

  useEffect(() => {

    const csrfToken = getCookie("csrftoken");

    if (!user) {
      axios
        .get(
          "/UserInfo",
          {
            headers: {
            "X-CSRFToken": csrfToken
            },
        }
        )
        .then(({ data }) => {
          setUser(data);
          setIsUserInfoReady(true);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, []);

  return (
    <UserContext.Provider value={{ user, setUser , isUserInfoReady}}>
      {children}
    </UserContext.Provider>
  );
};
