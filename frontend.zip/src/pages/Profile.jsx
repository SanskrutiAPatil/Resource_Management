// import { FaRegCircleUser } from "react-icons/fa6";
import { useContext, useEffect, useState } from "react"
import ProgressBar from "../components/ProgressBar"
import ReqFieldItem from "../components/ReqFieldItem"
import { getCookie } from "../utilities/getCSRF";
import axios from "axios";
import Spinner from "../components/Spinner";
import { UserContext } from "../context/userContext";
const Profile = () => {

  const [requests, setRequests] = useState(null);
  const {user, isUserInfoReady} = useContext(UserContext);

  useEffect(() => {
    const csrfToken = getCookie("csrftoken");
    axios.get(
        '/userrequests/',
        {
          headers: {
          "X-CSRFToken": csrfToken, 
          },
      }).then(({data}) => {
        setRequests(data.data);
        console.log(data.data);
      })
      .catch(error => {
        console.log(error);
      })
      
    }, []);
    

  const logout = () => {
    const csrfToken = getCookie("csrftoken");
    axios.get(
        '/logout/',
        {
          headers: {
          "X-CSRFToken": csrfToken, 
          },
      }).then(({data}) => {
        console.log(data);
      })
      .catch(error => {
        console.log(error);
      })
  }

  console.log(user);


  // if(!isUserInfoReady){
  //   return <Spinner />;
  // }




  const steps = [
    'You',
    'Teacher',
    'Resource Head',
    'Principle',
    'Director'
  ];

  // const step2 = [
  //   'You',
  //   'Teacher',
  //   'HOD',
  //   'Resource Head'
  // ]

  return (
    
    <>
        <div className=" mx-auto rounded-xl  grid grid-cols-4 gap-4 p-6 w-[99%] sm:w-[70%] md:[60%] mt-8 bg-gray-100">
          
          {isUserInfoReady && (
            <div className="col-span-3 gap-6  grid grid-cols-2 px-4 ">
            <ReqFieldItem  label="Name" value={user[" user Details"].Username !== "" ?  user[" user Details"].Username : "Add Name edit btn"} />
            <ReqFieldItem  label="Position" value={user[" user Details"].Role} />
            <ReqFieldItem  label="Email" value={user[" user Details"].email} />
            <ReqFieldItem label="Organization" value={user[" user Details"].organization} />          
          </div>
          )}

          <div className="flex flex-col justify-end gap-2">
              <button className="text-md transition-all duration-300 text-center  font-semibold text-white border border-white px-4 py-2 cursor-pointer rounded-xl bg-gray-500 hover:bg-gray-800 hover:text-white" >Edit</button>
              <button className="text-md transition-all duration-300 text-center  font-semibold text-white border border-white px-4 py-2 cursor-pointer rounded-xl bg-gray-500 hover:bg-gray-800 hover:text-white" >Change Password</button>
              <button onClick={logout} className="text-md transition-all duration-300 text-center  font-semibold text-white border border-white px-4 py-2 cursor-pointer rounded-xl bg-gray-500 hover:bg-gray-800 hover:text-red-500 " >Logout</button>
            </div>
          

        </div>




        <div className="flex flex-col gap-4 mt-8">

          {!requests && <Spinner/>}

          {requests && requests.length === 0 && <h1 className="text-center text-2xl">No Requests Made...</h1>}

          {requests && 
            requests.map(request => <ProgressBar steps={steps} request={request} key={request.booking_id + "req"} />)
          }
        </div>
    </>
  )
}

export default Profile