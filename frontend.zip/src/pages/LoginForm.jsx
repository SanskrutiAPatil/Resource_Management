import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useState } from 'react';
import axios from "axios";
import {Navigate} from 'react-router-dom';



const Login = () => {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [redirect, setRedirect] = useState(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post('/login/', {
                email, password
            })
            console.log(response);
            response.status === 200 ? alert("Login Successful") : alert("Login Failed");
            setRedirect(true);
        } catch (error) {
            console.error(error);
        }
    }

    if(redirect) {
        return <Navigate to="/" />
    }


    return (
        <>
        <form className='flex justify-center justify-items-center' > 


            <div className=' rounded-lg subpixel-antialiased flex flex-col justify-center justify-items-center shadow-lg bg-gray-50 py-12 my-32 md:px-16 sm:px-2 md:mx-32 sm:mx-6 mx-2 md:w-1/2 border sm:w-5/6 w-5/6'>

                <div className='text-center font-normal md:text-4xl text-3xl mb-8'>Login Form
                </div>


                <div className='flex justify-center'>
                    <TextField
                        id="email"
                        label="Email"
                        required
                        value={email}
                        style={{ width: "60%", marginBottom: "20px" }}
                        onChange={(event) => setEmail(event.target.value)}
                    />
                </div>

                <div className='flex justify-center'>
                    <TextField
                        style={{ width: "60%", marginBottom: "12px" }}
                        required
                        type="password"
                        id="password"
                        label="Password"
                        value={password}
                        onChange={(event) => setPassword(event.target.value)}
                    />
                </div>

                <div className='subpixel-antialiased mb-2 text-blue-500 flex justify-center'>
                    <div style={{ width: "60%" }}>
                        <a href="#" >Forget Passswod?</a>
                    </div>
                </div>

                <div className='flex justify-center'>
                    <Button onClick={(event) => handleSubmit(event)} variant="contained" style={{ marginTop: "12px", textAlign: "center" }}>Log In</Button>
                </div>

            </div>

        </form>
        </>
    );
}

export default Login